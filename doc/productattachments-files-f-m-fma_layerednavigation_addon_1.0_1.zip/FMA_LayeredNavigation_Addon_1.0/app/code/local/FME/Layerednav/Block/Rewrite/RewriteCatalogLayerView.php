<?php
/**
* FME Layered Navigation 
* 
* @category     FME
* @package      FME_Layerednav 
* @copyright    Copyright (c) 2010-2011 FME (http://www.fmeextensions.com/)
* @author       FME (Kamran Rafiq Malik)  
* @version      Release: 1.0.0
* @Class        FME_Layerednav_Block_Rewrite_RewriteCatalogLayerView
*/ 
class FME_Layerednav_Block_Rewrite_RewriteCatalogLayerView extends Mage_Catalog_Block_Layer_View
{
  
}